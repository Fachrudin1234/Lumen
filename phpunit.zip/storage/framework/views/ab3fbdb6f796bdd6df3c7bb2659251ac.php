<?php $__env->startSection("content"); ?>
<div class="d-flex justify-content-center m-3 ">
    <a href="" class="text-decoration-none p-2 m-2 btn btn-primary shadow">Pembayaran</a>
    <a href="<?php echo e(route('history2',[Auth::user()->id])); ?>" class="text-decoration-none p-2 m-2 btn btn-outline-primary">verivikasi</a>
    <a href="" class="text-decoration-none p-2 m-2 btn btn-outline-primary">Selesai</a>
</div>
<div class="d-flex flex-wrap justify-content-center">
    <?php $__currentLoopData = $Pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4 m-3 shadow">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Pembayaran <?php echo e($bayar->product->name_product); ?></h5>
                    <p class="card-text">Jumlah yang harus di bayar: Rp.<?php echo e($bayar->biaya); ?></p>
                    <p class="card-text">batas pembayaran 2x24 jam</p>
                    <a href="#" class="btn btn-primary">Cancel</a>
                    <a href="<?php echo e(route('bayar', [$bayar->id])); ?>" class="btn btn-primary">Bayar</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fachrudin\Documents\Laravel UAS\Lumen\resources\views/history.blade.php ENDPATH**/ ?>