<?php $__env->startSection("content"); ?>
<div class="d-flex justify-content-center m-3 ">
    <a href="<?php echo e(route('history',[Auth::user()->id])); ?>" class="text-decoration-none p-2 m-2 btn btn-outline-primary">Pembayaran</a>
    <a href="" class="text-decoration-none p-2 m-2 btn btn-primary shadow">verivikasi</a>
    <a href="" class="text-decoration-none p-2 m-2 btn btn-outline-primary">Selesai</a>
</div>
<div class="d-flex flex-wrap justify-content-center">
    <?php $__currentLoopData = $Pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-4 m-3 shadow">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Yang Sudah di bayar: Rp.<?php echo e($bayar->biaya); ?></h5>
                <p class="card-text">Harga: <?php echo e($bayar->product->harga); ?></p>
                <p class="card-text">Menungu Verivikasi</p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fachrudin\Documents\Laravel UAS\Lumen\resources\views/history2.blade.php ENDPATH**/ ?>