<?php $__env->startSection('admin_content'); ?>
<div class="container-md d-flex justify-content-center">
    <div class="container-md mt-4">
        <p class="display-4 fw-bold">Selamat Datang Admin</p>
        <p class="h4 fw-normal ">Semangat!
        </p>
    </div>
    <div class="container-md mt-4">
        <img class="img-fluid float-lg-start"
            src="<?php echo e(Vite::asset('resources/images/undraw_winter_designer_a-2-m7(1) 1.svg')); ?>" alt="bg">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fachrudin\Documents\Laravel UAS\Lumen\resources\views/admin/homeadmin.blade.php ENDPATH**/ ?>