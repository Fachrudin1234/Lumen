<?php $__env->startSection('admin_content'); ?>
<div class="container-md d-flex justify-content-center mt-3">
    <div class="border border-4 border-black p-4 rounded shadow">
        <div class="d-flex justify-content-center ">
            <div class="me-4 d-flex align-items-center" style="min-width: 500px; min-height: 400px;">
                <img id="frame" src="" class="img-fluid rounded" style="max-width: 500px; max-height: 500px;" />
            </div>
            <div class="mt-4">
                <form action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <p class="h2 fw-bold text-center mb-3">Tambah Product</p>
                    <div class="justify-content-center d-flex">
                        <div class="me-4">
                            <div class="mb-3">
                                <label for="Nama_Product" class="form-label">Nama Product</label>
                                <input type="text" class="form-control" id="Nama_Product" name="Nama_Product"
                                    value="<?php echo e(old('Nama_Product')); ?>">
                                <?php $__errorArgs = ['Nama_Product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><small><?php echo e($message); ?></small></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="Harga" class="form-label">Harga</label>
                                <input type="text" class="form-control" id="Harga" name="Harga"
                                    value="<?php echo e(old('Harga')); ?>">
                                <?php $__errorArgs = ['Harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><small><?php echo e($message); ?></small></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <div class="mb-3">
                                <label for="Code" class="form-label">Code Product</label>
                                <input type="text" class="form-control" id="Code" name="Code"
                                    value="<?php echo e(old('Code')); ?>">
                                <?php $__errorArgs = ['Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><small><?php echo e($message); ?></small></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="Stock" class="form-label">Stock</label>
                                <input type="text" class="form-control" id="Stock" name="Stock"
                                    value="<?php echo e(old('Stock')); ?>">
                                <?php $__errorArgs = ['Stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><small><?php echo e($message); ?></small></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlTextarea1" class="form-label">Deskripsi</label>
                        <textarea class="form-control fw-medium text-decoration-none bg-white "
                            id="exampleFormControlTextarea1" rows="4"
                            style="width:450px;
                            resize:none;" id="Deskripsi" name="Deskripsi" ></textarea>
                        <?php $__errorArgs = ['Deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><small><?php echo e($message); ?></small></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <label for="Image" class="form-label">image Product</label>
                    <input class="form-control" type="file" id="formFile" onchange="preview()" name="imgproduct">
                    <div class="d-flex justify-content-center mb-3 mt-4">
                        <button type="submit" class="btn btn-primary px-5">Tambah Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function preview() {
                frame.src = URL.createObjectURL(event.target.files[0]);
            }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fachrudin\Documents\Laravel UAS\Lumen\resources\views/admin/add.blade.php ENDPATH**/ ?>