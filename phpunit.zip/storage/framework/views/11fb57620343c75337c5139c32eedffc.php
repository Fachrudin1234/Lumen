<?php $__env->startSection("content"); ?>
    <p class="display-5 fw-bold text-center mt-4">Temukan Furniture</p>
    <p class="h3 fw-light text-center mt-0">Sesuai Keingin anda!</p>
    <div class="d-flex flex-wrap justify-content-center mt-4">
        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card m-4" style="width: 18rem;">
                    <img src="<?php echo e(Vite::asset('public/storage/files/img/'.$Product->encrypted_imagename)); ?>" class="card-img-top" alt="..." style="height: 250px;">
                    <div class="card-body">
                        <h5 class="card-title text-capitalize text-center"><?php echo e($Product->name_product); ?></h5>
                        <p class="card-text mb-0">Harga</p>
                        <p class="mt-0 h4 fw-medium">Rp.<?php echo e($Product->harga); ?></p>
                        <div class=" d-flex justify-content-center mt-4">
                            <a href="<?php echo e(route('detailproduct', [$Product->id])); ?>" class="btn btn-primary px-5">Beli</a>
                        </div>
                    </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fachrudin\Documents\Laravel UAS\Lumen\resources\views/product.blade.php ENDPATH**/ ?>